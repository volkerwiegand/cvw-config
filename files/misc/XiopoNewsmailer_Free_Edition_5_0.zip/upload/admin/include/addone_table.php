<?php
$color_selector ="<div id=\"color_select_table\" style=\"position:absolute; left:20px; top:20px; z-index:1; display:none;\">
<script type=\"text/javascript\"><!--
var color_in;function ini() {value = new Array(18),value[0]=\"00\",value[1]=\"11\",value[2]=\"22\",value[3]=\"33\",value[4]=\"44\",value[5]=\"55\",value[6]=\"66\",
value[7]=\"77\",value[8]=\"88\",value[9]=\"99\",value[10]=\"AA\",value[11]=\"BB\",value[12]=\"CC\",value[13]=\"DD\",
value[14]=\"EE\",value[15]=\"FF\",value[16]=\"C0\",value[17]=\"80\"}
function color_on(action) {if (!action)action = window.event;document.getElementById(\"color_select_table\").style.left = action.clientX+\"px\";
document.getElementById(\"color_select_table\").style.top = action.clientY+\"px\";document.getElementById(\"color_select_table\").style.display = \"block\";}
function color_off(kw,lw,mw) {document.getElementById(\"color_select_table\").style.display = \"none\";document.getElementsByName(color_in)[0].value = \"#\" + value[kw] + value[lw] + value[mw];
if(document.getElementById(color_in).style.backgroundColor) {document.getElementById(color_in).style.backgroundColor = \"#\" + value[kw] + value[lw] + value[mw];
} else {document.getElementsByName(color_in)[1].style.backgroundColor = \"#\" + value[kw] + value[lw] + value[mw];}}
function change_color(value_name,value_value) {if(document.getElementById(value_name).style.backgroundColor) {document.getElementById(value_name).style.backgroundColor = value_value;
} else {document.getElementsByName(value_name)[1].style.backgroundColor = value_value;}}
function show_colors_table() {var field_value = '';field_value += '<table border=\"0\" cellpadding=\"0\" cellspacing=\"2\" style=\"background-color:#f6f6f6; border-width:0px; border-color:white; border-style:solid;\">';
field_value += '<tr><td align=\"right\" colspan=\"13\"><span style=\"float:left; font-family:Arial,sans-serif; font-size:10px; color:black;\">$outtextshow521</span><span style=\"float:right; font-family:Arial,sans-serif; font-size:10px; color:black;\" class=\"color_table_link\"><a href=\"#\" onclick=\"document.getElementById(\'color_select_table\').style.display=\'none\'\">$outtextshow522</font></a></span></td></tr>';
for(var i=0; i<18; i++) {field_value += '<tr>';for(var j=0; j<13; j++) {if (i < 6)if (j < 6) k = 5;else k = 4;if ((i > 5) && (i < 12))if (j < 6) k = 2;else k = 3;if (i > 11)if (j < 6) k = 1;
else k = 0;if (i < 6) l = 5 - i;if ((i > 5) && (i < 12)) l = i - 6;if (i > 11) l = 17 - i;if (j < 6) m = j;else m = 11 - j;
if (j==12) {k = l = m = 17-i;} else {k *= 3;l *= 3;m *= 3;} color_add = \"\" + value[k] + value[l] + value[m];
field_value += '<td bgcolor=\"#' + color_add + '\">';field_value += '<a href=\"JavaScript:color_off(' + k + ',' + l + ',' + m + ')\" title=\"# ' + value[k] + ' ' + value[l] + ' ' + value[m] + '\">';field_value += '<img src=\"images/empty.png\" width=\"12\" height=\"12\" border=\"0\" alt=\"# ' + value[k] + ' ' + value[l] + ' ' + value[m] + '\"></a></td>';}
field_value += '</tr>';}field_value += '</table>';document.writeln(field_value);field_value = null;}ini();show_colors_table();
// -->
</script>
</div>
";