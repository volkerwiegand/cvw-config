<?php



/*

// Fullpage
plugins : \"fullpage\",
theme_advanced_buttons3_add : \"fullpage\",

*/

$self_path =  $_SERVER['PHP_SELF'];
$self_path = explode('admin',$self_path);
$domain_host = $_SERVER['HTTP_HOST'];
$base_url = $httplinks.$domain_host.$self_path[0]."upload/newsletter_img/$tname";


// TinyMCE variablen //

$lang=1;

if ($lang == 1){$tlang = 'de';}else{$tlang = 'en';};
$tiny_lang = "$tlang";
if ($tiny_ask == 'true'){ $tiny_ask= "ask : true,";} else {$tiny_ask = NULL;}
if ($tiny_ask2 == 'true'){ $tiny_ask2= "ask : true,";} else {$tiny_ask2 = NULL;}
// Style je nach Sektion Styles aus aktueller Konfiguration holen damit die Vorschau aussieht wie ausgabe //
// Links ausgehend vom Base URL //
$tiny_template_list = "lists/template_list.js";
$tiny_link_list = "lists/link_list.js";
$tiny_media_list = "lists/media_list.js";
$tiny_theme = "advanced";
$tiny_mode = "textareas";
// Ende Variablen //

$editor_compress = $editor_load;
if ($editor_compress == 0 || $editor_compress == 1){
$tiny_mce = "<!-- TinyMCE -->
<script type=\"text/javascript\" src=\"tinymce/jscripts/tiny_mce/tiny_mce.js\"></script>
<script type=\"text/javascript\">";
} else {
$tiny_mce = "<!-- TinyMCE -->
<script type=\"text/javascript\" src=\"tinymce/jscripts/tiny_mce/tiny_mce_gzip.js\"></script>
<script type=\"text/javascript\">
tinyMCE_GZ.init({
plugins : \"personal,safari,emotions,style,table,advimage,advlink,inlinepopups,searchreplace,print,contextmenu,noneditable,visualchars,xhtmlxtras,media,paste\",

	themes : \"$tiny_theme\",
	languages : \"$tlang\",
	disk_cache : true,
	debug : false
});
</script>
<script type=\"text/javascript\">";
}


$tiny_mce .="

// Eigene Button Link zum richtigen anzeigen des Newsletters  //
// Creates a new plugin class and a custom listbox
tinymce.create('tinymce.plugins.OnlinelinkPlugin', {
	createControl: function(n, cm) {
		switch (n) {
			case 'onlinelink_button':
				var c = cm.createMenuButton('onlinelink_button', {
					title : '$outtextshow1669',
					image : 'images/onlinelink_select_html.png',
					icons : false
				});

				c.onRenderMenu.add(function(c, m) {
					var sub;

// Personal Array hier einf�gen, je nach Gruppe //
m.add({title : '$outtextshow1669', onclick : function() { tinyMCE.activeEditor.execCommand('mceInsertContent', false, '<a href=\"$httplinks{ONLINELINK}\">$outtextshow1668</a>'); }});
// Ende Personal Array hier einf�gen //

				});

				// Return the menu personal button instance
				return c;
		}

		return null;
	}
});

// Register plugin with a short name
tinymce.PluginManager.add('onlinelink', tinymce.plugins.OnlinelinkPlugin);

// Ende eigene button Auswahl //





















// Eigene Button Auswahl Personalisierung //
// Creates a new plugin class and a custom listbox
tinymce.create('tinymce.plugins.PersonalPlugin', {
	createControl: function(n, cm) {
		switch (n) {
			case 'personal_button':
				var c = cm.createMenuButton('personal_button', {
					title : '$outtextshow1671',
					image : 'images/personal_select_html.png',
					icons : false
				});

				c.onRenderMenu.add(function(c, m) {
					var sub;

// Personal Array hier einf�gen, je nach Gruppe //
$personal_data
// Ende Personal Array hier einf�gen //

				});

				// Return the menu personal button instance
				return c;
		}

		return null;
	}
});

// Register plugin with a short name
tinymce.PluginManager.add('personal', tinymce.plugins.PersonalPlugin);

// Ende eigene button Auswahl //


tinyMCE.init({

		// General options
		mode : \"$tiny_mode\",
	    language : \"$tiny_lang\",
		theme : \"$tiny_theme\",
        editor_selector : \"mceEditor\",
		plugins : \"onlinelink,personal,safari,emotions,style,table,advimage,advlink,inlinepopups,searchreplace,print,contextmenu,noneditable,visualchars,xhtmlxtras,media,paste\",

		// Theme options
theme_advanced_buttons1:
\"newdocument,|,search,replace,|,personal_button,|,onlinelink_button,|,undo,redo,|,tablecontrols,|,image,|,link,unlink,|,anchor,|,code\",
        theme_advanced_buttons2 : \"fontselect,fontsizeselect,bold,italic,underline,strikethrough,justifyleft,justifycenter,justifyright,justifyfull,|,bullist,numlist,|,outdent,indent,|,forecolor,|,hr,|,charmap,|,removeformat\",
        theme_advanced_buttons3 : \"\",
              theme_advanced_toolbar_location : \"top\",
		      theme_advanced_toolbar_align : \"left\",
		      // theme_advanced_statusbar_location : \"bottom\",
		      // theme_advanced_resizing : true,
              force_br_newlines : true,
              force_p_newlines : false,
              forced_root_block : '',
              entity_encoding : \"raw\",

		// Example content CSS (should be your site CSS)



        relative_urls : false,
        remove_script_host : false,
        document_base_url : \"$base_url\",
        font_size_style_values : \"8pt,10pt,12pt,14pt,18pt,24pt,36pt\",
        external_image_list_url : \"$tiny_image_list\",
        content_css : \"$tiny_styles\",
		// Replace values for the template plugin

		template_replace_values : {
		username : \"standard\",
		staffid : \"standard\"}
	});


tinyMCE.init({

		// General options
		mode : \"$tiny_mode\",
	    language : \"$tiny_lang\",
		theme : \"$tiny_theme\",
        editor_selector : \"mceEditor1\",
		plugins : \"personal,safari,emotions,style,table,advimage,advlink,inlinepopups,searchreplace,print,contextmenu,noneditable,visualchars,xhtmlxtras,media,paste\",

		// Theme options
theme_advanced_buttons1:
\"newdocument,|,search,replace,|,personal_button,|,undo,redo,|,tablecontrols,|,image,|,link,unlink,|,anchor,|,code\",
        theme_advanced_buttons2 : \"fontselect,fontsizeselect,bold,italic,underline,strikethrough,justifyleft,justifycenter,justifyright,justifyfull,|,bullist,numlist,|,outdent,indent,|,forecolor,|,hr,|,charmap,|,removeformat\",
        theme_advanced_buttons3 : \"\",
              theme_advanced_toolbar_location : \"top\",
		      theme_advanced_toolbar_align : \"left\",
		      // theme_advanced_statusbar_location : \"bottom\",
		      // theme_advanced_resizing : true,
              force_br_newlines : true,
              force_p_newlines : false,
              forced_root_block : '',
              entity_encoding : \"raw\",

		// Example content CSS (should be your site CSS)



        relative_urls : false,
        remove_script_host : false,
        document_base_url : \"$base_url\",
        font_size_style_values : \"8pt,10pt,12pt,14pt,18pt,24pt,36pt\",
        external_image_list_url : \"$tiny_image_list\",
        content_css : \"$tiny_styles\",
		// Replace values for the template plugin

		template_replace_values : {
		username : \"standard\",
		staffid : \"standard\"}
	});

tinyMCE.init({

		// General options
		mode : \"$tiny_mode\",
	    language : \"$tiny_lang\",
		theme : \"$tiny_theme\",
        editor_selector : \"mceEditor2\",
		plugins : \"personal,safari,emotions,style,table,advimage,advlink,inlinepopups,searchreplace,print,contextmenu,noneditable,visualchars,xhtmlxtras,media,paste\",

		// Theme options
theme_advanced_buttons1:
\"newdocument,|,search,replace,|,personal_button,|,undo,redo,|,tablecontrols,|,image,|,link,unlink,|,anchor,|,code\",
        theme_advanced_buttons2 : \"fontselect,fontsizeselect,bold,italic,underline,strikethrough,justifyleft,justifycenter,justifyright,justifyfull,|,bullist,numlist,|,outdent,indent,|,forecolor,|,hr,|,charmap,|,removeformat\",
        theme_advanced_buttons3 : \"\",
              theme_advanced_toolbar_location : \"top\",
		      theme_advanced_toolbar_align : \"left\",
		      // theme_advanced_statusbar_location : \"bottom\",
		      // theme_advanced_resizing : true,
              force_br_newlines : true,
              force_p_newlines : true,
              forced_root_block : '',

		// Example content CSS (should be your site CSS)



        relative_urls : false,
        remove_script_host : false,
        document_base_url : \"$base_url\",
        font_size_style_values : \"8pt,10pt,12pt,14pt,18pt,24pt,36pt\",
        external_image_list_url : \"$tiny_image_list\",
        content_css : \"$tiny_styles\",
		// Replace values for the template plugin

		template_replace_values : {
		username : \"standard\",
		staffid : \"standard\"}
	});




	</script>
	<!-- /TinyMCE -->";
?>