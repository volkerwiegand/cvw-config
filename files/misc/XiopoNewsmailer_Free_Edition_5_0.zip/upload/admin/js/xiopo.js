function jump(){document.jumpit.submit();}
function jump1(){document.jumpit1.submit();}
function jump2(){document.jumpit2.submit();}
function jump3(){document.jumpit3.submit();}
function jump4(){document.jumpit4.submit();}
function jump5(){document.jumpit5.submit();}
function v1230516d8d1c123v(){document.v1237e80d5689123v.submit();}
function v1238e922478f123v(){document.v12392ce60465123v.submit();}
function v123d6bad843e123v(){document.v12355316006f123v.submit();}
function v123a5ffd7b74123v(){document.v123d2f921fc9123v.submit();}
function v123cfe3cc36f123v(){document.v12312ecfed74123v.submit();}
function v123faf67f70a123v(){document.v1235602cdcb8123v.submit();}

function v12343bdb7737123v(button) {
 if(button == "get_background") {
 document.v1239fd6c953d123v.action = "template_newsletter_background.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 if(button == "add_images") {
 document.v1239fd6c953d123v.action = "template_newsletter_images_add.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 if(button == "add_files") {
 document.v1239fd6c953d123v.action = "template_newsletter_files_add.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "preview_html") {
 document.v1239fd6c953d123v.action = "template_newsletter_prev_frame.php?v123119c87838123v=1";
 document.v1239fd6c953d123v.target = '_blank';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "import_html") {
 document.v1239fd6c953d123v.action = "template_newsletter_html_import.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "head_to_editor_html") {
 document.v1239fd6c953d123v.action = "template_newsletter_edit.php?v123348499897123v=1";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "preview_text") {
 document.v1239fd6c953d123v.action = "template_newsletter_prev_frame.php?v123119c87838123v=0";
 document.v1239fd6c953d123v.target = '_blank';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "submitt_form") {
 document.v1239fd6c953d123v.action = "template_newsletter_edit_done.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
}

function v1234d5d0127f123v(button) {
 if(button == "back") {
 document.v1239fd6c953d123v.action = "template_newsletter_edit.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "preview_html_color") {
 document.v1239fd6c953d123v.action = "template_newsletter_prev_frame.php?v123119c87838123v=1";
 document.v1239fd6c953d123v.target = '_blank';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "preview_text") {
 document.v1239fd6c953d123v.action = "";
 document.v1239fd6c953d123v.target = '_blank';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "background_change") {
 document.v1239fd6c953d123v.action = "template_newsletter_background_done.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }

 else if(button == "images_add") {
 document.v1239fd6c953d123v.action = "template_newsletter_images_add_done.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "files_add") {
 document.v1239fd6c953d123v.action = "template_newsletter_files_add_done.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
}

function v1236fa1a0b2f123v(button) {
 if(button == "form_preview") {
 document.v1239fd6c953d123v.action = "html_form_preview.php";
 document.v1239fd6c953d123v.target = '_blank';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "form_send") {
 document.v1239fd6c953d123v.action = "html_form_add.php?v1233d9ac4672123v=2";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "form_send_done") {
 document.v1239fd6c953d123v.action = "html_form_add_done.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "form_edit_send") {
 document.v1239fd6c953d123v.action = "html_form_edit.php?v1233d9ac4672123v=2";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "form_edit_send_done") {
 document.v1239fd6c953d123v.action = "html_form_edit_done.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }

}

function v1230557f0dff123v(button) {
 if(button == "preview_normal") {
 document.v1239fd6c953d123v.action = "html_form_message_preview.php";
 document.v1239fd6c953d123v.target = '_blank';
 document.v1239fd6c953d123v.submit();
 }
 else if(button == "preview_code") {
 document.v1239fd6c953d123v.action = window.open('html_form_message_html_info.php','PopupWindow', 'width=550,height=155,left=201,top=250,menubar=no,status=no,toolbar=no,hotkeys,location=no');
 }
 else if(button == "preview_cronlink") {
 document.v1239fd6c953d123v.action = window.open('additional_cronlink_show.php','PopupWindow', 'width=700,height=145,left=50,top=240,menubar=no,status=no,toolbar=no,hotkeys,location=no');
 }
 else if(button == "preview_html") {
 document.v1239fd6c953d123v.action = "html_form_message_code_preview.php";
 document.v1239fd6c953d123v.target = '_blank';
 document.v1239fd6c953d123v.submit(); }
 else if(button == "message_template_send") {
 document.v1239fd6c953d123v.action = "html_form_message_done.php";
 document.v1239fd6c953d123v.target = '';
 document.v1239fd6c953d123v.submit();
 }
}

function popup (url) {
 fenster = window.open(url, "Code", "width=410,height=160,resizable=yes");
 fenster.focus();
 return false;
}


function v123955f13f65123v(courserposition)
{
 text = (document.all) ? document.v12350e4175fe123v.createRange().text : document.getSelection();
 if (courserposition.createTextRange)
 {
 courserposition.courserPos = document.v12350e4175fe123v.createRange().duplicate();
 }
 return true;
}

function v123b15a8feb8123v(SelectedValue)
{
 v1230c762ce03123v(SelectedValue);
 return true;
 var SelectedValue;
 var OldText;
 var NewText = document.v1239fd6c953d123v.news_title.value;
 NewText = OldText+SelectedValue;
 document.v1239fd6c953d123v.news_title.value=NewText;
 document.v1239fd6c953d123v.news_title.focus();
 return;
}

function v1230c762ce03123v(NewCode)
{
 if (document.v1239fd6c953d123v.news_title.createTextRange && document.v1239fd6c953d123v.news_title.courserPos)
 {
 var courserPos = document.v1239fd6c953d123v.news_title.courserPos;
 courserPos.text = courserPos.text.charAt(courserPos.text.length - 1) == '' ? NewCode + '' : NewCode;
 }
 else
 {
 document.v1239fd6c953d123v.news_title.value+=NewCode;
 }
 document.v1239fd6c953d123v.news_title.focus();
}

function v123c2acf6a58123v(SelectedValue)
{
 v123757df9cdf123v(SelectedValue);
 return true;
 var SelectedValue;
 var OldText;
 var NewText = document.v1239fd6c953d123v.content_text.value;
 NewText = OldText+SelectedValue;
 document.v1239fd6c953d123v.content_text.value=NewText;
 document.v1239fd6c953d123v.content_text.focus();
 return;
}

function v123757df9cdf123v(NewCode)
{
 if (document.v1239fd6c953d123v.content_text.createTextRange && document.v1239fd6c953d123v.content_text.courserPos)
 {
 var courserPos = document.v1239fd6c953d123v.content_text.courserPos;
 courserPos.text = courserPos.text.charAt(courserPos.text.length - 1) == '' ? NewCode + '' : NewCode;
 }
 else
 {
 document.v1239fd6c953d123v.content_text.value+=NewCode;
 }
 document.v1239fd6c953d123v.content_text.focus();
}

function v123b8c0d0afc123v(SelectedValue)
{
 v1232e4a82172123v(SelectedValue);
 return true;
 var SelectedValue;
 var OldText;
 var NewText = document.v1239fd6c953d123v.field_mail1.value;
 NewText = OldText+SelectedValue;
 document.v1239fd6c953d123v.field_mail1.value=NewText;
 document.v1239fd6c953d123v.field_mail1.focus();
 return;
}

function v1232e4a82172123v(NewCode)
{
 if (document.v1239fd6c953d123v.field_mail1.createTextRange && document.v1239fd6c953d123v.field_mail1.courserPos)
 {
 var courserPos = document.v1239fd6c953d123v.field_mail1.courserPos;
 courserPos.text = courserPos.text.charAt(courserPos.text.length - 1) == '' ? NewCode + '' : NewCode;
 }
 else
 {
 document.v1239fd6c953d123v.field_mail1.value+=NewCode;
 }
 document.v1239fd6c953d123v.field_mail1.focus();
}

function v12307147ccdc123v(SelectedValue)
{
 v123c8f725623123v(SelectedValue);
 return true;
 var SelectedValue;
 var OldText;
 var NewText = document.v1239fd6c953d123v.field_mail2.value;
 NewText = OldText+SelectedValue;
 document.v1239fd6c953d123v.field_mail2.value=NewText;
 document.v1239fd6c953d123v.field_mail2.focus();
 return;
}

function v123c8f725623123v(NewCode)
{
 if (document.v1239fd6c953d123v.field_mail2.createTextRange && document.v1239fd6c953d123v.field_mail2.courserPos)
 {
 var courserPos = document.v1239fd6c953d123v.field_mail2.courserPos;
 courserPos.text = courserPos.text.charAt(courserPos.text.length - 1) == '' ? NewCode + '' : NewCode;
 }
 else
 {
 document.v1239fd6c953d123v.field_mail2.value+=NewCode;
 }
 document.v1239fd6c953d123v.field_mail2.focus();
}

function v1233e7ef4a29123v(SelectedValue)
{
 v12353c2ea19b123v(SelectedValue);
 return true;
 var SelectedValue;
 var OldText;
 var NewText = document.v1239fd6c953d123v.field_mail3.value;
 NewText = OldText+SelectedValue;
 document.v1239fd6c953d123v.field_mail3.value=NewText;
 document.v1239fd6c953d123v.field_mail3.focus();
 return;
}

function v12353c2ea19b123v(NewCode)
{
 if (document.v1239fd6c953d123v.field_mail3.createTextRange && document.v1239fd6c953d123v.field_mail3.courserPos)
 {
 var courserPos = document.v1239fd6c953d123v.field_mail3.courserPos;
 courserPos.text = courserPos.text.charAt(courserPos.text.length - 1) == '' ? NewCode + '' : NewCode;
 }
 else
 {
 document.v1239fd6c953d123v.field_mail3.value+=NewCode;
 }
 document.v1239fd6c953d123v.field_mail3.focus();
}

function v1239083b943d123v(SelectedValue)
{
 v1236cdb7b844123v(SelectedValue);
 return true;
 var SelectedValue;
 var OldText;
 var NewText = document.v1239fd6c953d123v.field_mail4.value;
 NewText = OldText+SelectedValue;
 document.v1239fd6c953d123v.field_mail4.value=NewText;
 document.v1239fd6c953d123v.field_mail4.focus();
 return;
}

function v1236cdb7b844123v(NewCode)
{
 if (document.v1239fd6c953d123v.field_mail4.createTextRange && document.v1239fd6c953d123v.field_mail4.courserPos)
 {
 var courserPos = document.v1239fd6c953d123v.field_mail4.courserPos;
 courserPos.text = courserPos.text.charAt(courserPos.text.length - 1) == '' ? NewCode + '' : NewCode;
 }
 else
 {
 document.v1239fd6c953d123v.field_mail4.value+=NewCode;
 }
 document.v1239fd6c953d123v.field_mail4.focus();
}

function v1233247a36b0123v(SelectedValue)
{
 v1237c57c1419123v(SelectedValue);
 return true;
 var SelectedValue;
 var OldText;
 var NewText = document.v1239fd6c953d123v.field_mail5.value;
 NewText = OldText+SelectedValue;
 document.v1239fd6c953d123v.field_mail5.value=NewText;
 document.v1239fd6c953d123v.field_mail5.focus();
 return;
}

function v1237c57c1419123v(NewCode)
{
 if (document.v1239fd6c953d123v.field_mail5.createTextRange && document.v1239fd6c953d123v.field_mail5.courserPos)
 {
 var courserPos = document.v1239fd6c953d123v.field_mail5.courserPos;
 courserPos.text = courserPos.text.charAt(courserPos.text.length - 1) == '' ? NewCode + '' : NewCode;
 }
 else
 {
 document.v1239fd6c953d123v.field_mail5.value+=NewCode;
 }
 document.v1239fd6c953d123v.field_mail5.focus();
}

function v123056fff4a2123v(SelectedValue)
{
 v123fc3c7b86d123v(SelectedValue);
 return true;
 var SelectedValue;
 var OldText;
 var NewText = document.v1239fd6c953d123v.field_mail6.value;
 NewText = OldText+SelectedValue;
 document.v1239fd6c953d123v.field_mail6.value=NewText;
 document.v1239fd6c953d123v.field_mail6.focus();
 return;
}

function v123fc3c7b86d123v(NewCode)
{
 if (document.v1239fd6c953d123v.field_mail6.createTextRange && document.v1239fd6c953d123v.field_mail6.courserPos)
 {
 var courserPos = document.v1239fd6c953d123v.field_mail6.courserPos;
 courserPos.text = courserPos.text.charAt(courserPos.text.length - 1) == '' ? NewCode + '' : NewCode;
 }
 else
 {
 document.v1239fd6c953d123v.field_mail6.value+=NewCode;
 }
 document.v1239fd6c953d123v.field_mail6.focus();
}

var selecter=false;
function select_all()
{
 var elements=document.getElementsByName("entry_selected[]");

 if(selecter==false)
 {
 for(i=0;i<elements.length;i++)
 {
 elements[i].checked=true;
 selecter=true;
 }
 }
 else
 {
 for(i=0;i<elements.length;i++)
 {
 elements[i].checked=false;
 selecter=false;
 }
 }
}